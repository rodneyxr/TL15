package core.lexer;

public enum TokenType {
	LP, RP, ASGN, SC, MULTIPLICATIVE, ADDITIVE, COMPARE, IF, THEN, ELSE, BEGIN, END, WHILE, DO, PROGRAM, VAR, AS, INT, BOOL, WRITEINT, READINT, num, boollit, ident
}
