This program is written Rodney Rodriguez in Java.

I have already ran the test cases under 'workdir/input'.
The results are in the 'output' directory at root of the project.

Example to run the program:

    ~$ cd workdir
    ~$ ./build.sh
    ~$ ./exec.sh input/test.tl
    
My program will output that some files have been created.
In this example, 'test.ast.dot', 'test.3A.cfg.dot' & 'test.s' will have been
created in same location as 'test.tl'.
