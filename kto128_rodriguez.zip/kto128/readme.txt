This program is written Rodney Rodriguez in Java.

Example to run the program:

    ~$ cd workdir
    ~$ ./build.sh
    ~$ ./exec.sh input/test.tl
    
My program will output that a file has been created.
In this example, 'test.ast.dot' will have been created in same location as 'test.tl'.
